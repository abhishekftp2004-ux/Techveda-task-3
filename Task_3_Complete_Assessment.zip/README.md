# Task 3 — Complete Assessment
Topic: Loops for Dataset Processing

Completed:
- for and while loops
- range(), break, continue
- Lists and dictionaries
- Numerical processing
- Summary statistics
- Student Marks processing
- Sales processing
- Employee processing
- Nested loops
- Mini project
- 10 interview questions and answers
- Conclusion and learning outcomes

Files:
- Task_3_Complete_Assessment.ipynb
- Task_3_Complete_Assessment.py
- student_marks.csv
- sales_sample.csv
- employee_sample.csv
