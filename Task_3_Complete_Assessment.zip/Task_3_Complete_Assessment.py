# Task 3 — Loops for Dataset Processing
import pandas as pd

students=pd.read_csv("student_marks.csv")
sales=pd.read_csv("sales_sample.csv")
employees=pd.read_csv("employee_sample.csv")

values=[12,25,8,42,17,30,5,64]
total=0; minimum=values[0]; maximum=values[0]
for value in values:
    total += value
    if value < minimum: minimum=value
    if value > maximum: maximum=value
print("Numerical Summary:", len(values), total, round(total/len(values),2), minimum, maximum)

total_marks=0; passed=0; failed=0
for mark in students["Marks"]:
    total_marks += mark
    if mark >= 40: passed += 1
    else: failed += 1
print("Student Summary:", round(total_marks/len(students),2), passed, failed)

records=sales.to_dict("records")
revenue=0; best=records[0]
for record in records:
    revenue += record["Units_Sold"]*record["Price_Per_Unit"]
    if record["Units_Sold"] > best["Units_Sold"]: best=record
print("Sales Summary:", revenue, best["Product"], best["Units_Sold"])

for employee in employees.to_dict("records"):
    if employee["Salary"]>=70000: level="Senior"
    elif employee["Salary"]>=40000: level="Mid-level"
    else: level="Entry-level"
    print(employee["Employee"], level)
